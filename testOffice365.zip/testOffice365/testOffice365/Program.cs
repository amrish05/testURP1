﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace testOffice365
{
    public static class Program
    {
        private static SharePointOnlineCredentials credential;
        static void Main(string[] args)
        {
            credential = GetAccessAccount();
            string sourcepath = @"D:\Template_CR_List.xlsx";
            string targetPath = @"https://microsoft.sharepoint.com/teams/cadsalesoperationalreports/Shared Documents/PowerBI/";
            var test = CopyFileToOffice365(sourcepath, targetPath);
        }
        /// <summary>
        /// Copy local file to Office365
        /// </summary>
        /// <param name="srcPathandFile">local file path : E:\ExcelForTest\source\All Escalations - Americas - Current Fiscal Year.xlsm</param>
        /// <param name="targetPathandFile">office365 file path : https://microsoft.sharepoint.com/teams/ECOCOSDev/China/Shared Documents/test1/test2/All Escalations - Americas - Current Fiscal Year.xlsm</param>
        /// <returns></returns>
        public static bool CopyFileToOffice365(string srcPathandFile, string targetPathandFile)
        {
            try
            {
                using (var client = new WebClient())
                {
                    client.Credentials = credential;
                    client.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f");
                    byte[] data = System.IO.File.ReadAllBytes(srcPathandFile);
                    client.UploadData(targetPathandFile, "PUT", data);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Get SharePointOnlineCredentials from database
        /// </summary>
        /// <returns>SharePointOnlineCredentials</returns>
        public static SharePointOnlineCredentials GetAccessAccount()
        {
            string account = string.Empty;
            string pwd = "Ilovemummy901*";

            SecureString passWord = new SecureString();
            foreach (char c in pwd.ToCharArray()) passWord.AppendChar(c);
            SharePointOnlineCredentials credential = new SharePointOnlineCredentials("v-amsiva@microsoft.com", passWord);
            return credential;
        }
    }
}
